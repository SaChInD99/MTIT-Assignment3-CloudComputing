﻿namespace MTIT.Manager.Models
{
    public class Manager
    {
        public int Id { get; set; }
        public string? ItemName { get; set; }

        public string? ItemQuantity { get; set; }

        public int ItemPrice { get; set; }
    }
}
